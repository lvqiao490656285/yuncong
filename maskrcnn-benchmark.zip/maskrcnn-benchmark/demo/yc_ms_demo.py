# Copyright (c) Facebook, Inc. and its affiliates. All Rights Reserved.
import argparse
import cv2

from maskrcnn_benchmark.config import cfg
from predictor import YCDemo

import time


def main():
    parser = argparse.ArgumentParser(description="PyTorch Object Detection Webcam Demo")
    parser.add_argument(
        "--config-file",
        default="/hdd/oujie/maskrcnn-benchmark/configs/yc/e2e_faster_rcnn_R_50_FPN_1x.yaml",
        metavar="FILE",
        help="path to config file",
    )
    parser.add_argument(
        "--confidence-threshold",
        type=float,
        default=0.01,
        help="Minimum score for the prediction to be shown",
    )
    parser.add_argument(
        "--min-image-size",
        type=int,
        default=800,
        help="Smallest size of the image to feed to the model. "
            "Model was trained with 800, which gives best results",
    )
    parser.add_argument(
        "--show-mask-heatmaps",
        dest="show_mask_heatmaps",
        help="Show a heatmap probability for the top masks-per-dim masks",
        action="store_true",
    )
    parser.add_argument(
        "--masks-per-dim",
        type=int,
        default=2,
        help="Number of heatmaps per dimension to show",
    )
    parser.add_argument(
        "opts",
        help="Modify model config options using the command-line",
        default=None,
        nargs=argparse.REMAINDER,
    )

    args = parser.parse_args()

    # load config from file and command-line arguments
    cfg.merge_from_file(args.config_file)
    cfg.merge_from_list(args.opts)
    cfg.freeze()

    # prepare object that handles inference plus adds predictions on top of image
    yc_demo = YCDemo(
        cfg,
        confidence_threshold=args.confidence_threshold,
        show_mask_heatmaps=args.show_mask_heatmaps,
        masks_per_dim=args.masks_per_dim,
        min_image_size=args.min_image_size,
    )

    """
    img=cv2.imread('/hdd/oujie/dataset/VOC_YC/Part_B/test_data/IMG_100.jpg')
    start_time = time.time()
    composite = yc_demo.run_on_opencv_image(img)
    print("Time: {:.2f} s / img".format(time.time() - start_time))
    cv2.imwrite("YCdetections.jpg", composite)
    """
    namelist = open('/hdd/oujie/dataset/VOC_YC/merged_list.txt', 'r')
    namelist = namelist.readlines()
    _ImagePath_ = '/hdd/oujie/dataset/VOC_YC/'

    save_test_result = open('/hdd/oujie/maskrcnn-benchmark/upload_yc/7w+_up100_smallanchors_res50fpn_0.01_nms0.5.txt', 'w')
    for j in range(len(namelist)):
        img = cv2.imread(_ImagePath_ + namelist[j][:-1] + '.jpg')
        hight = img.shape[0]
        width = img.shape[1]
        img_res, boxes, scores = yc_demo.run_on_opencv_image(img)
        if namelist[j][:-1]=='our/test/20/1050':
            cv2.imwrite("YCdetections.jpg", img_res)
        save_test_result.write(namelist[j])
        save_test_result.write(str(len(boxes))+'\n')
        for box, score in zip(boxes, scores):
            x0, y0,x1,y1 = box
            if x0 < 0:
                x0 = 0
            if x0 > width:
                continue
            if x1 <= 0:
                continue
            if x1 >= width:
                x1 = width - 1
            if y0 < 0:
                y0 = 0
            if y0 > hight:
                continue
            if y1 <= 0:
                continue
            if y1 >= hight:
                y1 = hight - 1
            w = int((x1 - x0))
            h = int((y1 - y0))
            x0 = int(x0)
            y0 = int(y0)
            #if score<0.5:
            #    score=0.5
            save_test_result.write(str(x0) + ' ' + str(y0) + ' ' + str(w) + ' ' + str(
                int(h)) + ' ' + str(round(score, 1)) + '\n')

if __name__ == "__main__":
    main()
