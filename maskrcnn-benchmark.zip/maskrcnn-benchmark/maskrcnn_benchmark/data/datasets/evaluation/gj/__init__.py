import logging

from .gj_eval import do_gj_evaluation


def gj_evaluation(dataset, predictions, output_folder, box_only, **_):
    logger = logging.getLogger("maskrcnn_benchmark.inference")
    if box_only:
        logger.warning("gj evaluation doesn't support box_only, ignored.")
    logger.info("performing gj evaluation, ignored iou_types.")
    return do_gj_evaluation(
        dataset=dataset,
        predictions=predictions,
        output_folder=output_folder,
        logger=logger,
    )
